Para executar o trabalho siga os passos:
1. Entre no diretório src (cd src)
1. Torne o script para compilar os arquivos um executavel (sudo chmod +x compile.sh)
2. Execute ./compile.sh
3. Abra duas janelas do terminal
4. Em um deles rode ./router 1
5. Na outra janela rode ./router 2

PS: Não é muito mas é trabalho honesto.