Para avaliar o trabalho siga os passos:
1. Entre no diretório src (cd src)
1. Torne o script para compilar os arquivos um executável (sudo chmod +x compile.sh)
2. Execute ./compile.sh
3. Abra 3 janelas do terminal
4. Em uma delas rode ./router 1
5. Na outra rode ./router 2
6. E na outra rode ./router 3
7. Siga as instruções do menu

PS: Não é muito mas é trabalho honesto.
